The diagram you downloaded is available in these formats:
- DRAWIO
- SVG

You can customize them for your organization using the associated tools:
- For DRAWIO format, use draw.io for Confluence, online at diagrams.net, or the desktop app. Go to diagrams.net for more information.
- For SVG format, use an SVG editor such as Inkscape or Sketsa SVG Editor, which are free and available for Windows, macOS, Linux.